replaceitem entity @s slot.armor.head 1 pa:just_joke_suit_scorpion
replaceitem entity @s slot.weapon.mainhand 0 air