effect @e[hasitem={item=pa:just_joke_suit_subzero,location=slot.armor.head}] invisibility 1 0 true
