summon pa:statue_huggy
