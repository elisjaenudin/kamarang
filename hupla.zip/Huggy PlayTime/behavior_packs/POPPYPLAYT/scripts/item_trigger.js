import { world, system } from "@minecraft/server";
    

world.beforeEvents.worldInitialize.subscribe(initEvent => { {initEvent.itemComponentRegistry.registerCustomComponent("pa_grabpack3:trigger", {
    onUse: e => {
        const equippable = e.source.getComponent("minecraft:equippable");
        if (!equippable) return;
        const mainhand = equippable.getEquipmentSlot("Mainhand");
        if (!mainhand.hasItem()) return;
        mainhand.amount++;
    },
})
}
{initEvent.itemComponentRegistry.registerCustomComponent("pa_grabpack2:trigger", {
    onUse: e => {
        const equippable = e.source.getComponent("minecraft:equippable");
        if (!equippable) return;
        const mainhand = equippable.getEquipmentSlot("Mainhand");
        if (!mainhand.hasItem()) return;
        mainhand.amount++;
    },
})
}
{initEvent.itemComponentRegistry.registerCustomComponent("pa_grabpack:trigger", {
    onUse: e => {
        const equippable = e.source.getComponent("minecraft:equippable");
        if (!equippable) return;
        const mainhand = equippable.getEquipmentSlot("Mainhand");
        if (!mainhand.hasItem()) return;
        mainhand.amount++;
    },
})
}
{initEvent.itemComponentRegistry.registerCustomComponent("pa_grabpack1:trigger", {
    onUse: e => {
        const equippable = e.source.getComponent("minecraft:equippable");
        if (!equippable) return;
        const mainhand = equippable.getEquipmentSlot("Mainhand");
        if (!mainhand.hasItem()) return;
        mainhand.amount++;
    },
})
} });
