give @s hv:flashlight
give @s hv:crossbow
