effect @e[family=forest,r=10] slowness 2 255 true
playanimation @e[type=hv:wendigo,r=10] animation.wendigo.stop
playanimation @e[type=hv:wendigo_hungry,r=10] animation.wendigo_hungry.stop
playsound mob.wendigo.stop @a