execute at @e[type=hv:wendigo_hungry,r=2] run ride @e[r=4,family=!forest] start_riding @s
execute at @e[type=hv:wendigo_hungry,r=2] run effect @e[r=4,family=!forest] blindness 2 1 true
execute as @s run playsound mob.wendigo.jumpscare @a ~ ~ ~
effect @s slowness 4 255 true
