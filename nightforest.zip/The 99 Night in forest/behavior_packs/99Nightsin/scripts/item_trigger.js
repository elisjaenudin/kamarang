import { system, world } from '@minecraft/server';


world.beforeEvents.worldInitialize.subscribe(initEvent => { initEvent.itemComponentRegistry.registerCustomComponent('flashlight_use:trigger', {
  onUse: e => { e.source.runCommand("function flashlight_use"); },
});
 });
