summon sando:cutechucky
give @p cookie 7