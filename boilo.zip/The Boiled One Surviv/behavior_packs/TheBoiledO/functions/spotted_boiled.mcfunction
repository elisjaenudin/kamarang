effect @e [type=mod:boiled] slowness 4 255 true
effect @e [type=mod:boiled] weakness 9999 255 true
effect @p[r=35] slowness 4 6 true
playsound mob.mod_boiled.death @a