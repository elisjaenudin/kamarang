tp @e [type=mod:boiled] 1000 1 1000
title @a title §4!!you boiled!!