give @p thelake:lucky_block 

