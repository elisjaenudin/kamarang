gamerule sendcommandfeedback false
scoreboard players set @a[r=5, m=survival] Scarrr 0
effect @e[type=mebesm:jackie3, c=1] slowness 5 255 true
schedule delay add Blackk 38
schedule delay add killl 40t
ride @p[m=survival] start_riding @e[type=mebesm:jackie3, c=1]
effect @p blindness 5 3 true
camerashake add @p 0.05 0.5 positional
playsound scream @p
playanimation @e[type=mebesm:jackie3, c=1] animation.mebesm_jackie3.scream