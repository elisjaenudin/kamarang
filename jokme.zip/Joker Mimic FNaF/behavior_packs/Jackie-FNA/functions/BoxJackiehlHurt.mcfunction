playanimation @e[type=mebesm:jackie_box, c=1] animation.mebesm_jackie_box.krut
playsound kruk @a[r=15]