summon mebesm:box1 ~ ~ ~ ~
playsound go @a[r=15]