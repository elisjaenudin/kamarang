gamerule sendcommandfeedback false
scoreboard objectives add Scarrr dummy
scoreboard players add @a[r=5, m=survival] Scarrr 1
execute as @a[r=6, m=survival, scores={Scarrr=7..}] run function Boxjackie3Scar