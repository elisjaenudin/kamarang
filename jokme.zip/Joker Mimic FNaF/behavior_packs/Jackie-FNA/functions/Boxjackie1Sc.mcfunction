gamerule sendcommandfeedback false
scoreboard objectives add Scar dummy
scoreboard players add @a[r=5, m=survival] Scar 1
execute as @a[r=6, m=survival, scores={Scar=7..}] run function Boxjackie1Scar